"""
Gemini 3 Pro Image Generation — Step 5 of the Forward Pipeline
================================================================
After user confirms the ELK SVG rendering has all components,
this module takes the SVG as input and requests Gemini 3 Pro Image
model to generate a publication-quality scientific figure (PNG/image).

Flow:
  1. (Optional) Grok 4 reverse-engineers a professional prompt from a
     reference image + paper method text
  2. Gemini 3 Pro Image generates the final scientific figure

API format: Gemini native v1beta/models/{model}:generateContent
  - Uses tryallai.com proxy: GEMINI_API_BASE
  - responseModalities: ["TEXT", "IMAGE"]
  - imageConfig: { aspectRatio, imageSize }

GitHub references:
  - gemini-cli-extensions/nanobanana
  - ZeroLu/awesome-nanobanana-pro
"""

from __future__ import annotations

import base64
import json
import logging
import re
from typing import Any, Dict, List, Optional

import httpx

from ..ai_engine import AIEngine
from ..config import Settings, get_settings

logger = logging.getLogger(__name__)


# ============================================================================
# Grok 4 Prompt Engineering — Step a
# ============================================================================

GROK_PROMPT_ENGINEER_SYSTEM = """\
You are an expert AI art director specializing in academic/scientific figure design.
Your task: analyze the provided SVG layout and paper method description,
then generate a DETAILED prompt for an AI image generator (Gemini 3 Pro Image)
to create a publication-quality scientific figure.

Your prompt must cover:
1. **Visual Style**: Clean, professional academic illustration style
   (vector-like, flat design with subtle gradients, Nature/Science quality)
2. **Layout & Composition**: Describe spatial arrangement matching the SVG structure
3. **Core Elements**: Each component/module with shape, color, label
4. **Color Palette**: Professional scientific palette
   (blues, teals, soft oranges for accents, white background)
5. **Typography**: Clean sans-serif labels, readable at print size
6. **Connections**: Arrows, flow lines with clear directionality
7. **Details**: Shadows, borders, rounded corners, padding
8. **Do NOT include**: Any text formatting, markdown, or code fences

Output ONLY the prompt text, nothing else. The prompt should be 200-400 words,
highly specific, and directly usable as input to Gemini 3 Pro Image.
"""

GROK_PROMPT_ENGINEER_USER = """\
Based on this paper method description and SVG layout, generate a detailed
AI image generation prompt for creating a publication-quality scientific figure.

Paper Method:
{method_text}

SVG Layout (describes component positions and connections):
{svg_content}

Generate the detailed prompt now:
"""


async def generate_prompt_with_grok(
    ai_engine: AIEngine,
    method_text: str,
    svg_content: str,
    model: Optional[str] = None,
    reference_image_b64: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Step a: Use Grok 4 (or specified model) to reverse-engineer a professional
    prompt from the SVG + method text (+ optional reference image).

    Args:
        ai_engine: Initialized AIEngine
        method_text: Paper method description
        svg_content: The ELK-generated SVG content
        model: Model to use (defaults to grok-4 via OpenAI-compatible)
        reference_image_b64: Optional base64-encoded reference image

    Returns:
        dict with success, prompt, model_used
    """
    settings = get_settings()
    use_model = model or settings.OPENAI_DEFAULT_MODEL  # grok-4

    user_content = GROK_PROMPT_ENGINEER_USER.format(
        method_text=method_text,
        svg_content=svg_content[:8000],  # Truncate SVG if too long
    )

    # If reference image provided, add it to context
    if reference_image_b64:
        user_content = (
            "I have a reference scientific figure (attached as image) that I want "
            "the generated figure to emulate in style. Analyze its visual style, "
            "color scheme, layout approach, and quality level.\n\n"
            + user_content
        )

    try:
        logger.info(f"Grok prompt engineering: model={use_model}")

        result = await ai_engine.get_completion(
            messages=[
                {"role": "system", "content": GROK_PROMPT_ENGINEER_SYSTEM},
                {"role": "user", "content": user_content},
            ],
            model=use_model,
            temperature=0.7,
            max_tokens=2048,
        )

        prompt = result.get("content", "").strip()
        if not prompt:
            return {
                "success": False,
                "error": "Grok returned empty prompt",
                "model_used": use_model,
            }

        logger.info(f"Grok prompt generated: {len(prompt)} chars")
        return {
            "success": True,
            "prompt": prompt,
            "model_used": result.get("model", use_model),
        }

    except Exception as e:
        logger.error(f"Grok prompt engineering failed: {e}")
        return {
            "success": False,
            "error": str(e),
            "model_used": use_model,
        }


# ============================================================================
# Gemini 3 Pro Image Generation — Step b
# ============================================================================

async def generate_image_with_gemini(
    svg_content: str,
    prompt: str,
    settings: Optional[Settings] = None,
    model: str = "gemini-3-pro-image-preview",
    aspect_ratio: str = "16:9",
    image_size: str = "4K",
) -> Dict[str, Any]:
    """
    Step b: Use Gemini 3 Pro Image model (via tryallai.com proxy)
    to generate a publication-quality scientific figure.

    Uses Gemini native format: v1beta/models/{model}:generateContent
    with responseModalities: ["TEXT", "IMAGE"]

    Args:
        svg_content: The ELK-generated SVG (as context for the figure)
        prompt: The detailed prompt (from Grok 4 or user)
        settings: Backend settings
        model: Gemini image model name
        aspect_ratio: Image aspect ratio
        image_size: Output size (e.g. "4K")

    Returns:
        dict with success, image_b64, mime_type, text_response, model_used
    """
    if settings is None:
        settings = get_settings()

    api_key = settings.GEMINI_API_KEY
    api_base = settings.GEMINI_API_BASE

    if not api_key:
        return {"success": False, "error": "GEMINI_API_KEY not configured"}

    # Determine endpoint
    # tryallai uses OpenAI-compatible base but Gemini native format needs v1beta path
    if api_base and "tryallai" in api_base:
        # tryallai.com proxy: use v1beta native Gemini format
        base_url = api_base.rstrip("/").replace("/v1", "")
        endpoint = f"{base_url}/v1beta/models/{model}:generateContent"
    elif api_base:
        base_url = api_base.rstrip("/")
        endpoint = f"{base_url}/v1beta/models/{model}:generateContent"
    else:
        # Direct Google API
        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

    # Build the request body (Gemini native format)
    # Combine SVG context with the generation prompt
    combined_prompt = (
        f"{prompt}\n\n"
        f"The figure should match this SVG layout structure:\n"
        f"```svg\n{svg_content[:6000]}\n```\n\n"
        f"Generate a high-quality scientific figure image based on the above."
    )

    request_body = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"text": combined_prompt}
                ],
            }
        ],
        "generationConfig": {
            "responseModalities": ["TEXT", "IMAGE"],
            "imageConfig": {
                "aspectRatio": aspect_ratio,
                "imageSize": image_size,
            },
        },
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }

    # For direct Google API, use query param instead of header
    params = {}
    if not api_base or "googleapis" in (api_base or ""):
        headers.pop("Authorization", None)
        params["key"] = api_key

    try:
        logger.info(
            f"Gemini image gen: model={model}, "
            f"aspect={aspect_ratio}, size={image_size}, "
            f"endpoint={endpoint[:60]}..."
        )

        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                endpoint,
                json=request_body,
                headers=headers,
                params=params if params else None,
            )

        if response.status_code != 200:
            error_text = response.text[:500]
            logger.error(f"Gemini image API error {response.status_code}: {error_text}")
            return {
                "success": False,
                "error": f"Gemini API error {response.status_code}: {error_text}",
                "model_used": model,
            }

        data = response.json()
        return _parse_gemini_image_response(data, model)

    except httpx.TimeoutException:
        return {
            "success": False,
            "error": "Gemini image generation timed out (120s). Try a simpler prompt.",
            "model_used": model,
        }
    except Exception as e:
        logger.error(f"Gemini image gen failed: {e}")
        return {
            "success": False,
            "error": str(e),
            "model_used": model,
        }


def _parse_gemini_image_response(data: dict, model: str) -> Dict[str, Any]:
    """
    Parse Gemini generateContent response which may contain both text and image parts.

    Response format:
    {
      "candidates": [{
        "content": {
          "role": "model",
          "parts": [
            { "text": "..." },
            { "inlineData": { "mimeType": "image/png", "data": "base64..." } }
          ]
        }
      }]
    }
    """
    candidates = data.get("candidates", [])
    if not candidates:
        return {
            "success": False,
            "error": "Gemini returned no candidates",
            "model_used": model,
        }

    content = candidates[0].get("content", {})
    parts = content.get("parts", [])

    text_response = ""
    image_b64 = None
    mime_type = "image/png"

    for part in parts:
        if "text" in part:
            text_response += part["text"]
        if "inlineData" in part:
            inline = part["inlineData"]
            image_b64 = inline.get("data", "")
            mime_type = inline.get("mimeType", "image/png")

    if not image_b64:
        return {
            "success": False,
            "error": "Gemini response contained no image data",
            "text_response": text_response,
            "model_used": model,
        }

    logger.info(
        f"Gemini image generated: {len(image_b64)} base64 chars, "
        f"mime={mime_type}"
    )

    return {
        "success": True,
        "image_b64": image_b64,
        "mime_type": mime_type,
        "text_response": text_response,
        "model_used": model,
    }


# ============================================================================
# Combined Pipeline: Grok 4 prompt + Gemini 3 image
# ============================================================================

async def generate_scientific_figure(
    ai_engine: AIEngine,
    method_text: str,
    svg_content: str,
    reference_image_b64: Optional[str] = None,
    prompt_model: Optional[str] = None,
    image_model: str = "gemini-3-pro-image-preview",
    aspect_ratio: str = "16:9",
    image_size: str = "4K",
    custom_prompt: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Combined Step 5 pipeline:
      a) Grok 4 generates detailed prompt from SVG + method text
      b) Gemini 3 Pro Image generates the scientific figure

    Args:
        ai_engine: Initialized AIEngine
        method_text: Paper method description
        svg_content: ELK-generated SVG
        reference_image_b64: Optional reference image (base64)
        prompt_model: Model for prompt engineering (default: grok-4)
        image_model: Gemini image model
        aspect_ratio: Image aspect ratio
        image_size: Image size
        custom_prompt: Skip Grok and use this prompt directly

    Returns:
        dict with success, image_b64, mime_type, prompt, prompt_model, image_model
    """
    settings = get_settings()

    # Step a: Generate prompt (or use custom)
    if custom_prompt:
        prompt = custom_prompt
        prompt_model_used = "custom"
    else:
        prompt_result = await generate_prompt_with_grok(
            ai_engine=ai_engine,
            method_text=method_text,
            svg_content=svg_content,
            model=prompt_model,
            reference_image_b64=reference_image_b64,
        )

        if not prompt_result.get("success"):
            # Fallback: build a basic prompt ourselves
            prompt = _build_fallback_prompt(method_text, svg_content)
            prompt_model_used = "fallback"
            logger.warning(
                f"Grok prompt failed ({prompt_result.get('error')}), using fallback"
            )
        else:
            prompt = prompt_result["prompt"]
            prompt_model_used = prompt_result.get("model_used", "unknown")

    # Step b: Generate image
    image_result = await generate_image_with_gemini(
        svg_content=svg_content,
        prompt=prompt,
        settings=settings,
        model=image_model,
        aspect_ratio=aspect_ratio,
        image_size=image_size,
    )

    return {
        "success": image_result.get("success", False),
        "image_b64": image_result.get("image_b64"),
        "mime_type": image_result.get("mime_type", "image/png"),
        "text_response": image_result.get("text_response", ""),
        "prompt": prompt,
        "prompt_model_used": prompt_model_used,
        "image_model_used": image_result.get("model_used", image_model),
        "error": image_result.get("error"),
    }


def _build_fallback_prompt(method_text: str, svg_content: str) -> str:
    """Build a basic prompt when Grok is unavailable."""
    # Extract labels from SVG to understand components
    labels = re.findall(r'>([^<]{2,50})<', svg_content)
    unique_labels = list(dict.fromkeys(labels))[:20]  # Deduplicate, max 20
    components = ", ".join(unique_labels) if unique_labels else "neural network components"

    return (
        f"Create a high-quality scientific architecture diagram for an academic paper. "
        f"The figure should show: {method_text[:500]}. "
        f"Key components include: {components}. "
        f"Style: Clean, professional vector illustration suitable for a top-tier "
        f"machine learning conference (NeurIPS, ICLR, CVPR). "
        f"Use a professional color palette with soft blues, teals, and warm accents. "
        f"White background, clean sans-serif text labels, rounded rectangles for modules, "
        f"smooth directional arrows for data flow. "
        f"The figure should be immediately understandable and visually striking."
    )
