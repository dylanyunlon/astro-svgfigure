# Phase 1 Backend AI Engine — Git Instructions

## Branch
```bash
git checkout -b feature/phase1-backend-ai-engine
```

## Files added (12 files, 2789 lines)
```
.env.example                          |   39 ++
.gitignore                            |    1 + (__pycache__/)
backend/__init__.py                   |   30 +
backend/ai_engine.py                  | 1022 +  ← Core: 4 providers + factory
backend/config.py                     |  140 +
backend/pipeline/__init__.py          |   33 +
backend/pipeline/nanobanana_bridge.py |  257 +
backend/pipeline/scaffold_builder.py  |  262 +
backend/pipeline/svg_scaler.py        |  260 +
backend/pipeline/svg_validator.py     |  236 +
backend/pipeline/topology_gen.py      |  274 +
backend/schemas.py                    |  235 +
```

## Commit message
```
feat(backend): Phase 1 - AI Engine + Pipeline (Tasks 010, 013-022)

Implements core Python backend with multi-provider AI Engine
(modeled after skynetCheapBuy/app/core/ai_engine.py) and
forward SVG generation pipeline.

Providers: OpenAI, Anthropic, Google Gemini, ClaudeCompatible
Pipeline: topology_gen -> scaffold_builder -> nanobanana -> validator -> scaler
Codex parallel tasks: Phase 2+ (ELK TS lib, frontend, pages)
```

## Push
```bash
git add -A
git commit -m "feat(backend): Phase 1 - AI Engine + Pipeline (Tasks 010, 013-022)"
git push origin feature/phase1-backend-ai-engine
```

## PR Title
```
feat(backend): Phase 1 — AI Engine Multi-Provider + Forward SVG Pipeline
```

## Codex can now work on these 10 parallel tasks (Phase 2+):
- Task 023-036: Astro pages (generate, gallery, playground, API routes)
- Task 037-040: Layouts (GenerateLayout, FullWidthLayout)
- Task 041-056: Pipeline components (PipelineSteps, TextInput, etc.)
- Task 075-084: ELK TS library (layout.ts, algorithms.ts, to-svg.ts, etc.)

## Testing
```bash
cd astro-svgfigure
pip install pydantic pydantic-settings httpx --break-system-packages
python3 -c "from backend.pipeline import *; print('OK')"
```
