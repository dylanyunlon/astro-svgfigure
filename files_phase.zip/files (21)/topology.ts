/**
 * POST /api/topology — Text → Topology JSON
 *
 * Proxies request to Python FastAPI backend (localhost:8000)
 * which runs the LLM topology generation via backend/pipeline/topology_gen.py
 *
 * GitHub 背书: withastro/astro (API Routes), ResearAI/AutoFigure
 */
import type { APIRoute } from 'astro'

export const prerender = false

const BACKEND_URL = import.meta.env.BACKEND_URL || 'http://localhost:8000'

export const POST: APIRoute = async ({ request }) => {
  try {
    const body = await request.json()
    const { text, model, algorithm, direction } = body

    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: 'text field is required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Forward to Python backend
    const backendRes = await fetch(`${BACKEND_URL}/api/topology`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: text.trim(),
        model: model || 'gemini-2.0-flash',
        algorithm: algorithm || 'layered',
        direction: direction || 'DOWN',
      }),
    })

    if (!backendRes.ok) {
      const errorText = await backendRes.text()
      return new Response(
        JSON.stringify({ error: `Backend error: ${backendRes.status}`, details: errorText }),
        { status: backendRes.status, headers: { 'Content-Type': 'application/json' } }
      )
    }

    const data = await backendRes.json()
    return new Response(JSON.stringify(data), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    })
  } catch (err: any) {
    return new Response(
      JSON.stringify({
        error: 'Failed to connect to backend',
        details: err.message,
        hint: 'Make sure Python backend is running: python server.py',
      }),
      { status: 502, headers: { 'Content-Type': 'application/json' } }
    )
  }
}
